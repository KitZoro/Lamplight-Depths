# Lamplight Depths

A modern Linux dungeon RPG that combines Lamplight's original furry world with the structure and compact readability of Daniel Lawrence's DEC-era **DND**. It retains graphical tiles, portraits, sound, mouse support and safe modern saving while presenting exploration, statistics, commands and encounters like a mainframe expedition.

All code, maps, names and artwork in this package are new and original. The supplied historical DND and Moria files are not redistributed.

## Install and play

Open a terminal inside this folder and run:

```bash
chmod +x INSTALL.sh
./INSTALL.sh
./run.sh
```

The installer creates a private Python environment and installs `pygame-ce`. Ubuntu or Linux Mint may first require:

```bash
sudo apt install python3-venv
```

## Controls

- **WASD / arrows:** Move (`X` also moves south in the DEC tradition)
- **E / Enter:** Use stairs or interact
- **T:** Light a torch (120 turns)
- **Space / period:** Wait
- **F5:** Save
- **Esc / Q:** Pause and save/quit
- **F11:** Fullscreen
- **M:** Mute/unmute music and effects
- **Combat:** `F` fight, `C` class skill, `H` heal, `E` evade, `S` stay
- **Combat menus:** Arrow keys and Enter, or number keys 1–5

Menus and combat choices also support the mouse.

## Design

- Six races: Bunny, Fox, Ferret, Cat, Chicken and Human
- Four independent classes: Knight, Archer, Priest and Mage
- Three selectable dungeon campaigns: Moonroot Warrens, Emberdeep Vault and Glass Catacomb
- Twenty levels in each campaign, ending with the Orb guardian
- Town expeditions resume from the deepest level reached
- Fresh, authored-feeling procedural floors built from compact mainframe-style map cells
- Separate turn-based combat menu
- DEC-inspired split layout with persistent character statistics, compact map and expedition log
- Letter commands alongside modern arrow, mouse and number-key controls
- Race bonuses and class-specific combat skills
- Gold is temporary until returned safely to town
- Adventure mode is recoverable; Classic mode uses true permanent death
- Autosave plus manual F5 save
- Automatic migration of earlier Lamplight Depths save files
- Active encounters and completed victories persist across restarts
- Atomic save writes to protect progress during interruptions
- Resizable window and F11 fullscreen
- Original two-minute ambient soundtrack and event sound effects
- Mouse-enabled menus with an animated responsiveness/audio indicator

Save data is kept as `savegame.json` beside the game. Back it up if you want to preserve an Adventure-mode character.

## Visual credits

The title illustration, environment atlas and complete 24-character race/class atlas were generated specifically for Lamplight Depths. No Angband, Moria or historical DND graphics are included.
