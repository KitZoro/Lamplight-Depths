#!/usr/bin/env python3
"""Lamplight Depths - a modern, original DEC-DND-inspired dungeon RPG."""

from __future__ import annotations

import json
import math
import random
from pathlib import Path

try:
    import pygame
except ImportError:
    print("Lamplight Depths needs pygame-ce. Run ./INSTALL.sh first.")
    raise SystemExit(1)


ROOT = Path(__file__).resolve().parent
SAVE_FILE = ROOT / "savegame.json"
WIDTH, HEIGHT = 1280, 720
MAP_W, MAP_H, TILE = 43, 24, 20
MAP_X, MAP_Y = 370, 72
PANEL_X = 18

RACES = {
    "Bunny": {"str": -2, "int": 0, "wis": 2, "con": -1, "dex": 3, "cha": 1},
    "Fox": {"str": 0, "int": 2, "wis": 0, "con": -1, "dex": 2, "cha": 1},
    "Ferret": {"str": -1, "int": 1, "wis": 0, "con": 1, "dex": 2, "cha": 0},
    "Cat": {"str": 0, "int": 1, "wis": 0, "con": 0, "dex": 2, "cha": 0},
    "Chicken": {"str": -2, "int": 0, "wis": 2, "con": 0, "dex": 1, "cha": 1},
    "Human": {"str": 0, "int": 0, "wis": 0, "con": 0, "dex": 0, "cha": 0},
}

CLASSES = {
    "Knight": {"hp": 34, "sp": 4, "attack": 7, "armor": 5, "main": "str"},
    "Archer": {"hp": 27, "sp": 8, "attack": 6, "armor": 3, "main": "dex"},
    "Priest": {"hp": 25, "sp": 16, "attack": 4, "armor": 3, "main": "wis"},
    "Mage": {"hp": 20, "sp": 20, "attack": 3, "armor": 1, "main": "int"},
}

# The original mainframe DND let an adventurer choose between several caves.
# These are new Lamplight campaigns with a similar role: the rules stay familiar,
# while danger and treasure pacing change.
DUNGEONS = {
    "Moonroot Warrens": {
        "danger": 0,
        "description": "A fair first descent through old roots and buried halls.",
    },
    "Emberdeep Vault": {
        "danger": 2,
        "description": "Hot ruins with stronger monsters and richer treasure.",
    },
    "Glass Catacomb": {
        "danger": 4,
        "description": "A severe expedition for experienced delvers.",
    },
}

MONSTERS = [
    ("Giant white louse", 1, 6, 2, 5, 2, 13),
    ("Kobold", 1, 9, 3, 7, 5, 14),
    ("Goblin", 2, 13, 4, 10, 8, 14),
    ("Orc", 4, 21, 6, 17, 13, 14),
    ("Ghoul", 6, 29, 8, 25, 20, 13),
    ("Troll", 9, 43, 11, 38, 32, 14),
    ("Giant", 12, 62, 15, 58, 48, 14),
    ("Balrog", 16, 88, 20, 90, 75, 15),
    ("Red dragon", 20, 145, 27, 180, 150, 15),
]

ENV_TILES = {".": 0, "#": 1, "+": 2, "<": 3, ">": 4, "C": 5, "A": 6, "F": 7}
SPECIES_COL = {name: i for i, name in enumerate(RACES)}
CLASS_ROW = {name: i for i, name in enumerate(CLASSES)}


def clamp(value, low, high):
    return max(low, min(high, value))


def default_player(name, race, klass, classic, dungeon="Moonroot Warrens"):
    base = {"str": 12, "int": 12, "wis": 12, "con": 12, "dex": 12, "cha": 12}
    for key, bonus in RACES[race].items():
        base[key] += bonus
    hp = CLASSES[klass]["hp"] + max(0, base["con"] - 10) * 2
    sp = CLASSES[klass]["sp"] + max(0, base[CLASSES[klass]["main"]] - 10)
    return {
        "name": name or "Delver", "race": race, "class": klass, "classic": classic,
        "level": 1, "xp": 0, "next_xp": 20, "hp": hp, "max_hp": hp,
        "sp": sp, "max_sp": sp, "bank": 0, "carried": 0, "potions": 2,
        "torches": 3, "light_turns": 120, "floor": 1, "stats": base, "kills": 0,
        "deepest_floor": 1, "won": False, "dungeon": dungeon,
    }


class Game:
    def __init__(self):
        pygame.init()
        pygame.display.set_caption("Lamplight Depths")
        self.fullscreen = False
        self.window = pygame.display.set_mode((WIDTH, HEIGHT), pygame.RESIZABLE)
        self.canvas = pygame.Surface((WIDTH, HEIGHT))
        self.clock = pygame.time.Clock()
        self.font = pygame.font.Font(None, 28)
        self.small = pygame.font.Font(None, 22)
        self.tiny = pygame.font.Font(None, 18)
        self.large = pygame.font.Font(None, 52)
        self.title_font = pygame.font.Font(None, 86)
        self.mono = pygame.font.SysFont("DejaVu Sans Mono", 23)
        self.mono_small = pygame.font.SysFont("DejaVu Sans Mono", 17)
        self.mono_large = pygame.font.SysFont("DejaVu Sans Mono", 36, bold=True)
        self.assets = self.load_assets()
        self.state = "title"
        self.title_choice = 0
        self.create_row = 0
        self.create_values = ["Bunny", "Priest", "Moonroot Warrens", "Adventure"]
        self.name_text = "Aster"
        self.player = None
        self.grid = []
        self.seen = set()
        self.enemies = []
        self.floors = {}
        self.px = self.py = 0
        self.combat_enemy = None
        self.combat_choice = 0
        self.guard = False
        self.messages = ["Welcome to Lamplight Depths."]
        self.running = True
        self.pause_choice = 0
        self.audio_ok = False
        self.audio_muted = False
        self.interaction_locked = False
        self.sounds = {}
        self.init_audio()

    def init_audio(self):
        try:
            if not pygame.mixer.get_init():
                pygame.mixer.init(frequency=22050, size=-16, channels=2, buffer=1024)
            audio = ROOT / "assets" / "audio"
            for name in ("click", "step", "hit", "coin", "heal", "danger", "stairs"):
                self.sounds[name] = pygame.mixer.Sound(audio / f"{name}.wav")
            pygame.mixer.music.load(audio / "lamplight_ambient.wav")
            pygame.mixer.music.set_volume(.24)
            pygame.mixer.music.play(-1)
            self.audio_ok = True
        except (pygame.error, OSError):
            self.audio_ok = False

    def play_sound(self, name):
        if self.audio_ok and not self.audio_muted and name in self.sounds:
            self.sounds[name].play()

    def toggle_audio(self):
        if not self.audio_ok:
            self.add_message("Audio could not initialize. Check your Linux sound output.")
            return
        self.audio_muted = not self.audio_muted
        if self.audio_muted:
            pygame.mixer.music.pause()
        else:
            pygame.mixer.music.unpause()
            self.play_sound("click")

    def load_assets(self):
        atlas = pygame.image.load(ROOT / "assets" / "dungeon_atlas.png").convert()
        chars = pygame.image.load(ROOT / "assets" / "characters.png").convert()
        title = pygame.image.load(ROOT / "assets" / "title.png").convert()
        env, env_large = [], []
        cw, ch = atlas.get_width() // 4, atlas.get_height() // 4
        for row in range(4):
            for col in range(4):
                image = atlas.subsurface((col * cw, row * ch, cw, ch)).copy()
                env.append(pygame.transform.smoothscale(image, (TILE, TILE)))
                env_large.append(pygame.transform.smoothscale(image, (245, 245)))
        env[ENV_TILES["#"]] = self.make_wall_tile()
        portraits = {}
        cw, ch = chars.get_width() // 6, chars.get_height() // 4
        for r, klass in enumerate(CLASSES):
            for c, race in enumerate(RACES):
                image = chars.subsurface((c * cw, r * ch, cw, ch)).copy()
                portraits[(race, klass, "tile")] = pygame.transform.smoothscale(image, (TILE, TILE))
                portraits[(race, klass, "large")] = pygame.transform.smoothscale(image, (150, 150))
        return {"env": env, "env_large": env_large, "portraits": portraits, "title": title}

    @staticmethod
    def make_wall_tile():
        """Draw a clean stone wall without a torch baked into every square."""
        wall = pygame.Surface((TILE, TILE))
        wall.fill((24, 29, 29))
        mortar = (13, 17, 18)
        stone = ((52, 58, 56), (45, 51, 50), (59, 63, 59))
        brick_h = 5
        for row, y in enumerate(range(0, TILE, brick_h)):
            offset = -5 if row % 2 else 0
            for col, x in enumerate(range(offset, TILE, 10)):
                rect = pygame.Rect(x + 1, y + 1, 9, brick_h - 1)
                pygame.draw.rect(wall, stone[(row + col) % len(stone)], rect)
                pygame.draw.line(wall, (72, 76, 70), rect.topleft, rect.topright)
            pygame.draw.line(wall, mortar, (0, y), (TILE - 1, y))
        return wall

    def text(self, value, x, y, color=(235, 234, 220), font=None, center=False):
        image = (font or self.font).render(str(value), True, color)
        rect = image.get_rect()
        rect.center = (x, y) if center else rect.center
        if not center:
            rect.topleft = (x, y)
        self.canvas.blit(image, rect)
        return rect

    def panel(self, rect, alpha=230, border=(103, 91, 65)):
        surface = pygame.Surface((rect.width, rect.height), pygame.SRCALPHA)
        surface.fill((13, 17, 20, alpha))
        pygame.draw.rect(surface, border, surface.get_rect(), 2, border_radius=7)
        self.canvas.blit(surface, rect)

    def add_message(self, message):
        self.messages.append(message)
        self.messages = self.messages[-5:]

    def toggle_fullscreen(self):
        self.fullscreen = not self.fullscreen
        flags = pygame.FULLSCREEN if self.fullscreen else pygame.RESIZABLE
        size = (0, 0) if self.fullscreen else (WIDTH, HEIGHT)
        self.window = pygame.display.set_mode(size, flags)

    def new_game(self):
        mode = self.create_values[3]
        self.player = default_player(
            self.name_text.strip(), self.create_values[0], self.create_values[1],
            mode == "Classic", self.create_values[2]
        )
        self.floors = {}
        self.enter_town(first=True)
        self.play_sound("heal")
        self.save()

    def save(self):
        if not self.player:
            return
        if self.player.get("classic") and self.player.get("dead"):
            return
        if self.state in ("dungeon", "combat", "pause") and self.grid:
            self.remember_floor()
        data = {
            "version": 4, "player": self.player, "grid": self.grid,
            "seen": list(self.seen), "enemies": self.enemies, "px": self.px, "py": self.py,
            "floors": self.floors,
            "in_dungeon": self.state in ("dungeon", "combat", "pause"),
            "state": self.state,
            "combat_position": ([self.combat_enemy["x"], self.combat_enemy["y"]]
                                if self.state == "combat" and self.combat_enemy else None),
        }
        try:
            temporary = SAVE_FILE.with_suffix(".json.tmp")
            temporary.write_text(json.dumps(data, indent=2), encoding="utf-8")
            temporary.replace(SAVE_FILE)
        except OSError:
            self.add_message("The game could not write the save file.")

    def load(self):
        if not SAVE_FILE.exists():
            self.add_message("No saved adventurer was found.")
            return False
        try:
            data = json.loads(SAVE_FILE.read_text(encoding="utf-8"))
            if not isinstance(data, dict):
                raise TypeError("Invalid save document")
            version = data.get("version", 1)
            if type(version) is not int or not 1 <= version <= 4:
                raise ValueError("Unsupported save version")
            player = data["player"]
            if not isinstance(player, dict):
                raise TypeError("Invalid player data")
            player.setdefault("dungeon", "Moonroot Warrens")
            self.validate_player(player)
            self.player = player
            self.player.setdefault("light_turns", 120)
            self.player.setdefault("deepest_floor", self.player["floor"])
            self.player.setdefault("won", False)
            if type(data.get("in_dungeon", False)) is not bool:
                raise TypeError("Invalid save location")
            in_dungeon = data.get("in_dungeon", False)
            grid = data.get("grid", [])
            enemies = data.get("enemies", [])
            px, py = data.get("px", 1), data.get("py", 1)
            seen_values = data.get("seen", [])
            if in_dungeon:
                self.validate_dungeon_save(grid, enemies, px, py, seen_values)
            raw_floors = data.get("floors", {}) if version >= 4 else {}
            self.floors = self.validate_floor_cache(raw_floors)
            self.grid = grid
            self.seen = {tuple(v) for v in seen_values}
            self.enemies = enemies
            self.px, self.py = px, py
            self.combat_enemy = None
            if in_dungeon:
                self.remember_floor()
            if self.player["won"]:
                self.grid = []
                self.seen = set()
                self.enemies = []
                self.combat_enemy = None
                self.state = "victory"
            elif in_dungeon:
                self.state = "dungeon"
                self.update_seen()
                if data.get("state") == "combat":
                    position = data.get("combat_position")
                    if (not isinstance(position, list) or len(position) != 2
                            or not all(isinstance(value, int) for value in position)):
                        raise ValueError("Invalid combat position")
                    self.combat_enemy = self.enemy_at(*position)
                    if not self.combat_enemy:
                        raise ValueError("Missing combat enemy")
                    self.state = "combat"
                    self.add_message(f"The battle with the {self.combat_enemy['name']} resumes.")
            else:
                self.enter_town()
            self.add_message(f"Welcome back, {self.player['name']}.")
            return True
        except (IndexError, KeyError, TypeError, ValueError, OSError, json.JSONDecodeError):
            self.player = None
            self.grid = []
            self.seen = set()
            self.enemies = []
            self.floors = {}
            self.combat_enemy = None
            self.state = "title"
            self.add_message("The save file could not be read.")
            return False

    @staticmethod
    def validate_player(player):
        required = {
            "name", "race", "class", "classic", "level", "xp", "next_xp",
            "hp", "max_hp", "sp", "max_sp", "bank", "carried", "potions",
            "torches", "floor", "stats", "kills",
        }
        if not isinstance(player, dict) or not required.issubset(player):
            raise ValueError("Incomplete player data")
        if not isinstance(player["name"], str) or not isinstance(player["classic"], bool):
            raise TypeError("Invalid player identity")
        if player["race"] not in RACES or player["class"] not in CLASSES:
            raise ValueError("Unknown race or class")
        if player.get("dungeon", "Moonroot Warrens") not in DUNGEONS:
            raise ValueError("Unknown dungeon")
        if not isinstance(player["stats"], dict) or not set(RACES["Human"]).issubset(player["stats"]):
            raise ValueError("Incomplete player stats")
        if any(type(player["stats"][key]) is not int for key in RACES["Human"]):
            raise ValueError("Invalid player stats")
        numeric = required - {"name", "race", "class", "classic", "stats"}
        if any(type(player[key]) is not int for key in numeric):
            raise ValueError("Invalid player number")
        if "light_turns" in player and type(player["light_turns"]) is not int:
            raise TypeError("Invalid light timer")
        if "deepest_floor" in player and type(player["deepest_floor"]) is not int:
            raise TypeError("Invalid deepest floor")
        if "won" in player and not isinstance(player["won"], bool):
            raise TypeError("Invalid victory state")
        if not 1 <= player["floor"] <= 20 or player["level"] < 1 or player["next_xp"] < 1:
            raise ValueError("Invalid player range")
        if player["max_hp"] <= 0 or not 0 < player["hp"] <= player["max_hp"]:
            raise ValueError("Invalid player health")
        if player["max_sp"] < 0 or not 0 <= player["sp"] <= player["max_sp"]:
            raise ValueError("Invalid player spirit")
        if any(player[key] < 0 for key in ("xp", "bank", "carried", "potions", "torches", "kills")):
            raise ValueError("Invalid player range")
        if player.get("light_turns", 0) < 0:
            raise ValueError("Invalid light timer")
        if not 1 <= player.get("deepest_floor", player["floor"]) <= 20:
            raise ValueError("Invalid deepest floor")
        if player.get("deepest_floor", player["floor"]) < player["floor"]:
            raise ValueError("Deepest floor precedes current floor")

    @staticmethod
    def validate_dungeon_save(grid, enemies, px, py, seen_values):
        allowed_tiles = set(ENV_TILES)
        if len(grid) != MAP_H or any(not isinstance(row, str) or len(row) != MAP_W for row in grid):
            raise ValueError("Invalid dungeon dimensions")
        if any(set(row) - allowed_tiles for row in grid):
            raise ValueError("Invalid dungeon tile")
        if sum(row.count("<") for row in grid) != 1 or sum(row.count(">") for row in grid) != 1:
            raise ValueError("Invalid dungeon stairs")
        if not isinstance(px, int) or not isinstance(py, int) or not (0 <= px < MAP_W and 0 <= py < MAP_H):
            raise ValueError("Invalid player position")
        if grid[py][px] == "#" or not isinstance(enemies, list) or not isinstance(seen_values, list):
            raise ValueError("Invalid dungeon state")
        enemy_keys = {"name", "x", "y", "hp", "max_hp", "atk", "xp", "gold", "tile"}
        positions = set()
        for enemy in enemies:
            if not isinstance(enemy, dict) or not enemy_keys.issubset(enemy):
                raise ValueError("Invalid enemy")
            if not (isinstance(enemy["x"], int) and isinstance(enemy["y"], int)):
                raise TypeError("Invalid enemy position")
            if not (0 <= enemy["x"] < MAP_W and 0 <= enemy["y"] < MAP_H):
                raise ValueError("Invalid enemy position")
            if any(type(enemy[key]) is not int for key in ("hp", "max_hp", "atk", "xp", "gold", "tile")):
                raise ValueError("Invalid enemy number")
            if grid[enemy["y"]][enemy["x"]] == "#" or enemy["tile"] not in range(16):
                raise ValueError("Invalid enemy state")
            if enemy["max_hp"] <= 0 or not 0 < enemy["hp"] <= enemy["max_hp"]:
                raise ValueError("Invalid enemy health")
            if enemy["atk"] < 0 or enemy["xp"] < 0 or enemy["gold"] < 0:
                raise ValueError("Invalid enemy reward")
            position = (enemy["x"], enemy["y"])
            if position in positions or position == (px, py):
                raise ValueError("Overlapping enemy")
            positions.add(position)
        for value in seen_values:
            if not isinstance(value, (list, tuple)) or len(value) != 2:
                raise ValueError("Invalid visibility data")
            if not all(isinstance(coord, int) for coord in value):
                raise ValueError("Invalid visibility data")
            if not (0 <= value[0] < MAP_W and 0 <= value[1] < MAP_H):
                raise ValueError("Invalid visibility data")

    def validate_floor_cache(self, raw_floors):
        if not isinstance(raw_floors, dict) or len(raw_floors) > 20:
            raise ValueError("Invalid floor cache")
        floors = {}
        for key, floor_data in raw_floors.items():
            if not isinstance(key, str) or not key.isdigit() or not 1 <= int(key) <= 20:
                raise ValueError("Invalid cached floor number")
            if not isinstance(floor_data, dict):
                raise TypeError("Invalid cached floor")
            grid = floor_data.get("grid", [])
            enemies = floor_data.get("enemies", [])
            seen = floor_data.get("seen", [])
            px, py = floor_data.get("px", 0), floor_data.get("py", 0)
            self.validate_dungeon_save(grid, enemies, px, py, seen)
            floors[key] = {
                "grid": grid, "enemies": enemies, "seen": seen, "px": px, "py": py,
            }
        return floors

    def remember_floor(self):
        if not self.player or not self.grid:
            return
        self.floors[str(self.player["floor"])] = {
            "grid": list(self.grid),
            "seen": [list(position) for position in self.seen],
            "enemies": [dict(enemy) for enemy in self.enemies],
            "px": self.px,
            "py": self.py,
        }

    def restore_floor(self, floor):
        floor_data = self.floors.get(str(floor))
        if not floor_data:
            return False
        self.grid = list(floor_data["grid"])
        self.seen = {tuple(position) for position in floor_data["seen"]}
        self.enemies = [dict(enemy) for enemy in floor_data["enemies"]]
        self.px, self.py = floor_data["px"], floor_data["py"]
        self.combat_enemy = None
        return True

    def place_beside(self, marker):
        for y, row in enumerate(self.grid):
            x = row.find(marker)
            if x < 0:
                continue
            occupied = {(enemy["x"], enemy["y"]) for enemy in self.enemies}
            for dx, dy in ((0, 1), (1, 0), (0, -1), (-1, 0),
                           (1, 1), (-1, 1), (1, -1), (-1, -1)):
                nx, ny = x + dx, y + dy
                if (0 <= nx < MAP_W and 0 <= ny < MAP_H
                        and self.grid[ny][nx] != "#" and (nx, ny) not in occupied):
                    self.px, self.py = nx, ny
                    return
            self.px, self.py = x, y
            return
        raise RuntimeError("Arrival staircase is missing")

    def enter_town(self, first=False):
        if not self.player:
            return
        banked = self.player["carried"]
        self.player["bank"] += banked
        self.player["carried"] = 0
        self.player["hp"] = self.player["max_hp"]
        self.player["sp"] = self.player["max_sp"]
        self.grid = []
        self.seen = set()
        self.enemies = []
        self.combat_enemy = None
        self.state = "town"
        if first:
            self.add_message("A new adventurer enters the Lamplight Guild.")
        elif banked:
            self.add_message(f"You safely bank {banked} gold.")
        self.save()

    def generate_floor(self, floor):
        rng = random.Random(random.randrange(1 << 30))
        dungeon = DUNGEONS[self.player.get("dungeon", "Moonroot Warrens")]
        danger = dungeon["danger"]
        grid = [["#" for _ in range(MAP_W)] for _ in range(MAP_H)]
        rooms = []
        for _ in range(80):
            if len(rooms) >= 10:
                break
            w, h = rng.randint(5, 10), rng.randint(4, 7)
            x, y = rng.randint(1, MAP_W - w - 2), rng.randint(1, MAP_H - h - 2)
            rect = pygame.Rect(x, y, w, h)
            if any(rect.inflate(2, 2).colliderect(other) for other in rooms):
                continue
            rooms.append(rect)
            for yy in range(y, y + h):
                for xx in range(x, x + w):
                    grid[yy][xx] = "."
            if len(rooms) > 1:
                ax, ay = rooms[-2].center
                bx, by = rect.center
                if rng.random() < .5:
                    self.carve_h(grid, ax, bx, ay); self.carve_v(grid, ay, by, bx)
                else:
                    self.carve_v(grid, ay, by, ax); self.carve_h(grid, ax, bx, by)
        if len(rooms) < 2:
            raise RuntimeError("Dungeon generation failed")
        self.px, self.py = rooms[0].center
        down_x, down_y = rooms[-1].center
        grid[self.py][self.px] = "<"
        grid[down_y][down_x] = ">"
        open_cells = [(x, y) for y in range(MAP_H) for x in range(MAP_W) if grid[y][x] == "."]
        rng.shuffle(open_cells)
        for marker in ["C"] * 4 + ["F", "A"]:
            if open_cells:
                x, y = open_cells.pop(); grid[y][x] = marker
        self.grid = ["".join(row) for row in grid]
        self.seen = set()
        self.enemies = []
        self.combat_enemy = None
        count = min(7 + floor + danger, 28)
        for _ in range(count):
            if not open_cells:
                break
            x, y = open_cells.pop()
            available = [m for m in MONSTERS if m[1] <= floor + 1 + danger]
            template = rng.choice(available[-min(4, len(available)):])
            name, depth, hp, atk, xp, gold, tile = template
            scale = 1 + max(0, floor + danger - depth) * .055
            reward_scale = 1 + danger * .12
            self.enemies.append({"name": name, "x": x, "y": y, "hp": int(hp * scale),
                                 "max_hp": int(hp * scale), "atk": int(atk * scale),
                                 "xp": int(xp * scale), "gold": int(gold * scale * reward_scale), "tile": tile})
        if floor == 20:
            name, depth, hp, atk, xp, gold, tile = MONSTERS[-1]
            self.enemies.append({"name": "Orb guardian", "x": down_x, "y": down_y,
                                 "hp": hp + 45, "max_hp": hp + 45, "atk": atk + 3,
                                 "xp": xp + 70, "gold": gold + 100, "tile": tile,
                                 "guardian": True})
        self.update_seen()

    @staticmethod
    def carve_h(grid, x1, x2, y):
        for x in range(min(x1, x2), max(x1, x2) + 1):
            grid[y][x] = "."

    @staticmethod
    def carve_v(grid, y1, y2, x):
        for y in range(min(y1, y2), max(y1, y2) + 1):
            grid[y][x] = "."

    def start_floor(self, floor, arrival="above"):
        if self.state in ("dungeon", "combat", "pause") and self.grid:
            self.remember_floor()
        self.player["floor"] = clamp(floor, 1, 20)
        self.player["deepest_floor"] = max(self.player.get("deepest_floor", 1), self.player["floor"])
        if not self.restore_floor(self.player["floor"]):
            self.generate_floor(self.player["floor"])
        self.place_beside("<" if arrival == "above" else ">")
        self.state = "dungeon"
        self.update_seen()
        self.add_message(
            f"You enter {self.player.get('dungeon', 'Moonroot Warrens')}, "
            f"level {self.player['floor']} ({self.player['floor'] * 50} feet)."
        )
        self.play_sound("stairs")
        self.save()

    def grid_set(self, x, y, value):
        row = list(self.grid[y]); row[x] = value; self.grid[y] = "".join(row)

    def line_clear(self, x0, y0, x1, y1):
        dx, dy = abs(x1 - x0), abs(y1 - y0)
        sx, sy = (1 if x0 < x1 else -1), (1 if y0 < y1 else -1)
        err = dx - dy
        while (x0, y0) != (x1, y1):
            e2 = 2 * err
            if e2 > -dy: err -= dy; x0 += sx
            if e2 < dx: err += dx; y0 += sy
            if (x0, y0) != (x1, y1) and self.grid[y0][x0] == "#":
                return False
        return True

    def update_seen(self):
        if not self.grid:
            return
        radius = self.sight_radius()
        for y in range(max(0, self.py-radius), min(MAP_H, self.py+radius+1)):
            for x in range(max(0, self.px-radius), min(MAP_W, self.px+radius+1)):
                if math.dist((x, y), (self.px, self.py)) <= radius and self.line_clear(self.px, self.py, x, y):
                    self.seen.add((x, y))

    def visible(self, x, y):
        return math.dist((x, y), (self.px, self.py)) <= self.sight_radius() and self.line_clear(self.px, self.py, x, y)

    def sight_radius(self):
        return 8 if self.player and self.player.get("light_turns", 0) > 0 else 4

    def advance_light(self):
        if self.player.get("light_turns", 0) > 0:
            self.player["light_turns"] -= 1
            if self.player["light_turns"] == 0:
                self.add_message("Your torch gutters out. The darkness closes in.")

    def use_torch(self):
        if self.player["torches"] <= 0:
            self.add_message("You have no spare torches.")
            return
        self.player["torches"] -= 1
        self.player["light_turns"] = self.player.get("light_turns", 0) + 120
        self.add_message("You light a fresh torch.")
        self.play_sound("heal")
        self.move_enemies()
        if self.state == "dungeon":
            self.update_seen()
        self.save()

    def enemy_at(self, x, y):
        return next((e for e in self.enemies if e["x"] == x and e["y"] == y), None)

    def move_player(self, dx, dy):
        nx, ny = self.px + dx, self.py + dy
        if not (0 <= nx < MAP_W and 0 <= ny < MAP_H) or self.grid[ny][nx] == "#":
            self.add_message("Cold stone blocks your way.")
            return
        enemy = self.enemy_at(nx, ny)
        if enemy:
            self.begin_combat(enemy)
            return
        self.px, self.py = nx, ny
        self.play_sound("step")
        self.resolve_feature()
        if self.state != "dungeon":
            self.save()
            return
        self.advance_light()
        self.move_enemies()
        self.update_seen()
        self.save()

    def resolve_feature(self, interacting=False):
        tile = self.grid[self.py][self.px]
        if tile == "C":
            danger = DUNGEONS[self.player.get("dungeon", "Moonroot Warrens")]["danger"]
            gold = int(random.randint(7, 20) * self.player["floor"] * (1 + danger * .12))
            self.player["carried"] += gold
            self.grid_set(self.px, self.py, ".")
            self.add_message(f"You find {gold} temporary gold. Escape alive to bank it!")
            self.play_sound("coin")
        elif tile == "F":
            roll = random.random()
            if roll < .55:
                healed = min(self.player["max_hp"] - self.player["hp"], random.randint(6, 15))
                self.player["hp"] += healed; self.add_message(f"The fountain restores {healed} HP.")
                self.play_sound("heal")
            elif roll < .82:
                self.player["sp"] = min(self.player["max_sp"], self.player["sp"] + 6)
                self.add_message("The fountain restores your spirit.")
                self.play_sound("heal")
            else:
                self.player["hp"] -= 5; self.add_message("Poison! The fountain burns within you.")
                self.play_sound("danger")
            self.grid_set(self.px, self.py, ".")
            if self.player["hp"] <= 0:
                self.die()
        elif tile == "A":
            if not interacting:
                self.add_message("An ancient altar waits. Press E to make an offering.")
            elif self.player["sp"] >= self.player["max_sp"]:
                self.add_message("Your spirit is already full; the altar takes nothing.")
            elif self.player["carried"] >= 10:
                self.player["carried"] -= 10
                self.player["sp"] = min(self.player["max_sp"], self.player["sp"] + 8)
                self.add_message("You offer 10 gold. A warm light answers.")
                self.play_sound("heal")
                return True
            else:
                self.add_message("The ancient altar waits for an offering.")
        return False

    def interact(self):
        tile = self.grid[self.py][self.px]
        if tile == "<":
            if self.player["floor"] == 1:
                self.remember_floor()
                self.enter_town()
            else:
                self.start_floor(self.player["floor"] - 1, arrival="below")
        elif tile == ">":
            if self.player["floor"] >= 20:
                if any(enemy.get("guardian") for enemy in self.enemies):
                    self.add_message("The Orb guardian still seals the final chamber.")
                else:
                    self.player["bank"] += self.player["carried"]
                    self.player["carried"] = 0
                    self.player["won"] = True
                    self.state = "victory"
            else:
                self.start_floor(self.player["floor"] + 1, arrival="above")
        elif tile == "A":
            if self.resolve_feature(interacting=True):
                self.advance_light()
                self.move_enemies()
                if self.state == "dungeon":
                    self.update_seen()
        else:
            self.add_message("There is nothing here to use.")

    def move_enemies(self):
        occupied = {(e["x"], e["y"]) for e in self.enemies}
        for enemy in list(self.enemies):
            if math.dist((enemy["x"], enemy["y"]), (self.px, self.py)) > 8:
                continue
            dx = 0 if enemy["x"] == self.px else (1 if self.px > enemy["x"] else -1)
            dy = 0 if enemy["y"] == self.py else (1 if self.py > enemy["y"] else -1)
            choices = [(dx, 0), (0, dy)]
            random.shuffle(choices)
            for mx, my in choices:
                if mx == my == 0:
                    continue
                nx, ny = enemy["x"] + mx, enemy["y"] + my
                if (nx, ny) == (self.px, self.py):
                    self.begin_combat(enemy); return
                if self.grid[ny][nx] != "#" and (nx, ny) not in occupied:
                    occupied.discard((enemy["x"], enemy["y"]))
                    enemy["x"], enemy["y"] = nx, ny
                    occupied.add((nx, ny)); break

    def begin_combat(self, enemy):
        self.combat_enemy = enemy
        self.combat_choice = 0
        self.guard = False
        self.state = "combat"
        self.add_message(f"A {enemy['name']} confronts you!")
        self.play_sound("danger")

    def player_damage(self):
        p, cls = self.player, CLASSES[self.player["class"]]
        stat = p["stats"][cls["main"]]
        return max(1, cls["attack"] + p["level"] // 2 + (stat - 10) // 2 + random.randint(-2, 3))

    def combat_action(self, index):
        p, e = self.player, self.combat_enemy
        if not e:
            self.state = "dungeon"; return
        enemy_turn = True
        if index == 0:
            damage = self.player_damage()
            e["hp"] -= damage
            self.add_message(f"You strike the {e['name']} for {damage}.")
            self.play_sound("hit")
        elif index == 1:
            klass = p["class"]
            if klass == "Knight":
                self.guard = True; self.add_message("You brace behind your shield.")
                self.play_sound("click")
            elif klass == "Archer":
                if p["sp"] < 2: self.add_message("You lack focus."); enemy_turn = False
                else:
                    p["sp"] -= 2; damage = self.player_damage() + random.randint(4, 8)
                    e["hp"] -= damage; self.add_message(f"Your aimed shot deals {damage}.")
                    self.play_sound("hit")
            elif klass == "Priest":
                if p["sp"] < 3: self.add_message("You lack spirit."); enemy_turn = False
                elif p["hp"] >= p["max_hp"]: self.add_message("You are already at full health."); enemy_turn = False
                else:
                    p["sp"] -= 3; amount = min(8 + p["level"], p["max_hp"] - p["hp"])
                    p["hp"] += amount
                    self.add_message(f"Your prayer restores {amount} HP.")
                    self.play_sound("heal")
            else:
                if p["sp"] < 3: self.add_message("You lack mana."); enemy_turn = False
                else:
                    p["sp"] -= 3; damage = 8 + p["level"] + random.randint(1, 6)
                    e["hp"] -= damage; self.add_message(f"Magic Missile deals {damage}.")
                    self.play_sound("hit")
        elif index == 2:
            if p["potions"] <= 0:
                self.add_message("You have no healing potions."); enemy_turn = False
            elif p["hp"] >= p["max_hp"]:
                self.add_message("You are already at full health."); enemy_turn = False
            else:
                p["potions"] -= 1; amount = min(random.randint(18, 30), p["max_hp"] - p["hp"])
                p["hp"] += amount
                self.add_message(f"The potion restores {amount} HP.")
                self.play_sound("heal")
        elif index == 3:
            chance = .38 + (p["stats"]["dex"] - 10) * .025
            if random.random() < chance:
                self.add_message(f"You evade the {e['name']}.")
                self.play_sound("step")
                self.state = "dungeon"; self.combat_enemy = None; self.save(); return
            self.add_message("You fail to escape!")
        else:
            self.add_message("You wait and watch.")
        if e["hp"] <= 0:
            self.win_combat(); return
        if enemy_turn:
            self.enemy_attack()
            if self.state == "dead":
                return
        self.save()

    def enemy_attack(self):
        p, e = self.player, self.combat_enemy
        armor = CLASSES[p["class"]]["armor"] + p["level"] // 4
        damage = max(1, e["atk"] + random.randint(-2, 3) - armor // 2)
        if self.guard:
            damage = max(0, damage // 2); self.guard = False
        p["hp"] -= damage
        self.add_message(f"The {e['name']} hits you for {damage}.")
        self.play_sound("hit")
        if p["hp"] <= 0:
            self.die()

    def win_combat(self):
        p, e = self.player, self.combat_enemy
        p["xp"] += e["xp"]; p["carried"] += e["gold"]; p["kills"] += 1
        self.add_message(f"You defeat the {e['name']} and take {e['gold']} gold.")
        if e in self.enemies: self.enemies.remove(e)
        self.combat_enemy = None
        while p["xp"] >= p["next_xp"]:
            p["level"] += 1; p["next_xp"] *= 2
            hp_gain = random.randint(5, 9) + max(0, p["stats"]["con"] - 10) // 2
            sp_gain = 2 + (2 if p["class"] in ("Priest", "Mage") else 1)
            p["max_hp"] += hp_gain; p["hp"] = p["max_hp"]
            p["max_sp"] += sp_gain; p["sp"] = p["max_sp"]
            self.add_message(f"You advance to level {p['level']}!")
        self.state = "dungeon"; self.save()

    def die(self):
        lost = self.player["carried"]
        self.player["carried"] = 0
        if self.player.get("classic"):
            self.player["dead"] = True
            try: SAVE_FILE.unlink(missing_ok=True)
            except OSError: pass
        else:
            self.player["hp"] = self.player["max_hp"]
            self.player["sp"] = self.player["max_sp"]
            self.grid = []
            self.seen = set()
            self.enemies = []
            self.combat_enemy = None
            self.state = "dead"
            self.save()
        self.state = "dead"
        self.add_message(f"The dungeon claims you. {lost} unbanked gold is lost.")
        self.play_sound("danger")

    def buy(self, kind):
        p = self.player
        if kind == "potion": cost = 35; key = "potions"
        else: cost = 10; key = "torches"
        if p["bank"] < cost:
            self.add_message("You cannot afford that."); return
        p["bank"] -= cost; p[key] += 1
        self.add_message(f"Purchased one {kind} for {cost} gold."); self.save()
        self.play_sound("coin")

    def handle_event(self, event):
        if event.type == pygame.QUIT:
            self.save(); self.running = False; return
        if event.type in (pygame.MOUSEMOTION, pygame.MOUSEBUTTONDOWN):
            self.handle_mouse(event)
            return
        if event.type == pygame.KEYUP:
            if event.key in (pygame.K_e, pygame.K_RETURN):
                self.interaction_locked = False
            return
        if event.type != pygame.KEYDOWN:
            return
        if event.key == pygame.K_F11:
            self.toggle_fullscreen(); return
        if event.key == pygame.K_m and not (self.state == "create" and self.create_row == 0):
            self.toggle_audio(); return
        if self.state == "title": self.handle_title(event)
        elif self.state == "create": self.handle_create(event)
        elif self.state == "town": self.handle_town(event)
        elif self.state == "dungeon": self.handle_dungeon(event)
        elif self.state == "combat": self.handle_combat(event)
        elif self.state == "pause": self.handle_pause(event)
        elif self.state in ("dead", "victory", "help") and event.key in (pygame.K_RETURN, pygame.K_ESCAPE):
            self.state = "title"

    def mouse_canvas_pos(self, event):
        ww, wh = self.window.get_size()
        scale = min(ww / WIDTH, wh / HEIGHT)
        draw_w, draw_h = WIDTH * scale, HEIGHT * scale
        offset_x, offset_y = (ww - draw_w) / 2, (wh - draw_h) / 2
        return (event.pos[0] - offset_x) / scale, (event.pos[1] - offset_y) / scale

    def handle_mouse(self, event):
        x, y = self.mouse_canvas_pos(event)
        clicked = event.type == pygame.MOUSEBUTTONDOWN and event.button == 1
        if self.state == "title":
            for i in range(4):
                if pygame.Rect(65, 285 + i * 50, 370, 48).collidepoint(x, y):
                    if self.title_choice != i: self.play_sound("click")
                    self.title_choice = i
                    if clicked:
                        if i == 0: self.state = "create"
                        elif i == 1: self.load()
                        elif i == 2: self.state = "help"
                        else: self.running = False
                    return
        elif self.state == "create" and clicked:
            for i in range(6):
                if pygame.Rect(145, 105 + i * 76, 670, 60).collidepoint(x, y):
                    self.create_row = i; self.play_sound("click")
                    if i == 1:
                        vals=list(RACES); self.create_values[0]=vals[(vals.index(self.create_values[0])+1)%len(vals)]
                    elif i == 2:
                        vals=list(CLASSES); self.create_values[1]=vals[(vals.index(self.create_values[1])+1)%len(vals)]
                    elif i == 3:
                        vals=list(DUNGEONS); self.create_values[2]=vals[(vals.index(self.create_values[2])+1)%len(vals)]
                    elif i == 4:
                        self.create_values[3]="Classic" if self.create_values[3]=="Adventure" else "Adventure"
                    elif i == 5: self.new_game()
                    return
        elif self.state == "town" and clicked:
            if pygame.Rect(320, 310, 600, 55).collidepoint(x,y): self.start_floor(self.player.get("deepest_floor", self.player["floor"]))
            elif pygame.Rect(320, 375, 650, 50).collidepoint(x,y): self.buy("potion")
            elif pygame.Rect(320, 425, 650, 50).collidepoint(x,y): self.buy("torch")
            elif pygame.Rect(320, 485, 650, 50).collidepoint(x,y): self.save(); self.state="title"
        elif self.state == "combat":
            for i in range(5):
                col, row = i%2, i//2
                if pygame.Rect(355+col*430, 473+row*55, 400, 48).collidepoint(x,y):
                    if self.combat_choice != i: self.play_sound("click")
                    self.combat_choice=i
                    if clicked: self.combat_action(i)
                    return
        elif self.state == "pause" and clicked:
            for i in range(2):
                if pygame.Rect(465, 305+i*65, 355, 55).collidepoint(x,y):
                    self.pause_choice=i; self.play_sound("click")
                    if i==0: self.state="dungeon"
                    else: self.save(); self.state="title"
                    return
        elif self.state in ("help", "dead", "victory") and clicked:
            self.state = "title"

    def handle_title(self, event):
        options = ["New adventurer", "Continue", "Controls", "Quit"]
        if event.key in (pygame.K_UP, pygame.K_w): self.title_choice = (self.title_choice - 1) % len(options)
        elif event.key in (pygame.K_DOWN, pygame.K_s): self.title_choice = (self.title_choice + 1) % len(options)
        elif event.key == pygame.K_RETURN:
            self.play_sound("click")
            if self.title_choice == 0: self.state = "create"
            elif self.title_choice == 1: self.load()
            elif self.title_choice == 2: self.state = "help"
            else: self.running = False

    def handle_create(self, event):
        if event.key == pygame.K_ESCAPE: self.state = "title"; return
        if self.create_row == 0 and event.key == pygame.K_BACKSPACE: self.name_text = self.name_text[:-1]; return
        if self.create_row == 0 and event.unicode.isprintable() and event.unicode not in "\r\n\t" and len(self.name_text) < 18:
            self.name_text += event.unicode; return
        if event.key in (pygame.K_UP, pygame.K_w): self.create_row = (self.create_row - 1) % 6
        elif event.key in (pygame.K_DOWN, pygame.K_s): self.create_row = (self.create_row + 1) % 6
        elif event.key in (pygame.K_LEFT, pygame.K_a, pygame.K_RIGHT, pygame.K_d):
            direction = -1 if event.key in (pygame.K_LEFT, pygame.K_a) else 1
            if self.create_row == 1:
                vals = list(RACES); i = vals.index(self.create_values[0]); self.create_values[0] = vals[(i + direction) % len(vals)]
            elif self.create_row == 2:
                vals = list(CLASSES); i = vals.index(self.create_values[1]); self.create_values[1] = vals[(i + direction) % len(vals)]
            elif self.create_row == 3:
                vals = list(DUNGEONS); i = vals.index(self.create_values[2]); self.create_values[2] = vals[(i + direction) % len(vals)]
            elif self.create_row == 4:
                self.create_values[3] = "Classic" if self.create_values[3] == "Adventure" else "Adventure"
        elif event.key == pygame.K_RETURN and self.create_row == 5:
            self.new_game()

    def handle_town(self, event):
        if event.key == pygame.K_1: self.start_floor(self.player.get("deepest_floor", self.player["floor"]))
        elif event.key == pygame.K_2: self.buy("potion")
        elif event.key == pygame.K_3: self.buy("torch")
        elif event.key in (pygame.K_ESCAPE, pygame.K_q): self.save(); self.state = "title"

    def handle_dungeon(self, event):
        moves = {pygame.K_UP:(0,-1), pygame.K_w:(0,-1), pygame.K_DOWN:(0,1), pygame.K_s:(0,1),
                 pygame.K_x:(0,1), pygame.K_LEFT:(-1,0), pygame.K_a:(-1,0),
                 pygame.K_RIGHT:(1,0), pygame.K_d:(1,0)}
        if event.key in moves: self.move_player(*moves[event.key])
        elif event.key in (pygame.K_e, pygame.K_RETURN):
            if not self.interaction_locked:
                self.interaction_locked = True
                self.interact()
                self.save()
        elif event.key in (pygame.K_SPACE, pygame.K_PERIOD):
            self.advance_light(); self.move_enemies(); self.update_seen(); self.save()
        elif event.key == pygame.K_t: self.use_torch()
        elif event.key == pygame.K_F5: self.save(); self.add_message("Game saved.")
        elif event.key in (pygame.K_ESCAPE, pygame.K_q): self.state = "pause"

    def handle_combat(self, event):
        direct = {
            pygame.K_f: 0, pygame.K_c: 1, pygame.K_h: 2,
            pygame.K_e: 3, pygame.K_s: 4, pygame.K_PERIOD: 4,
        }
        if event.key == pygame.K_UP: self.combat_choice = (self.combat_choice - 1) % 5
        elif event.key == pygame.K_DOWN: self.combat_choice = (self.combat_choice + 1) % 5
        elif event.key in direct: self.combat_action(direct[event.key])
        elif pygame.K_1 <= event.key <= pygame.K_5: self.combat_action(event.key - pygame.K_1)
        elif event.key == pygame.K_RETURN: self.combat_action(self.combat_choice)

    def handle_pause(self, event):
        if event.key in (pygame.K_UP, pygame.K_w, pygame.K_DOWN, pygame.K_s): self.pause_choice = 1 - self.pause_choice
        elif event.key == pygame.K_ESCAPE: self.state = "dungeon"
        elif event.key == pygame.K_RETURN:
            if self.pause_choice == 0: self.state = "dungeon"
            else: self.save(); self.state = "title"

    def draw_title(self):
        bg = pygame.transform.smoothscale(self.assets["title"], (WIDTH, HEIGHT))
        self.canvas.blit(bg, (0, 0))
        shade = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA); shade.fill((0, 0, 0, 55)); self.canvas.blit(shade, (0, 0))
        self.text("LAMPLIGHT", 72, 72, (250, 205, 91), self.title_font)
        self.text("DEPTHS", 76, 143, (238, 237, 221), self.title_font)
        self.text("The DEC-style furry dungeon expedition", 80, 220, (190, 200, 198), self.font)
        options = ["New adventurer", "Continue", "Controls", "Quit"]
        self.panel(pygame.Rect(65, 275, 370, 250), 205)
        for i, option in enumerate(options):
            color = (255, 207, 87) if i == self.title_choice else (230, 230, 220)
            self.text(("> " if i == self.title_choice else "  ") + option, 98, 305 + i * 50, color, self.large if i == self.title_choice else self.font)
        if not SAVE_FILE.exists(): self.text("No save yet", 80, 548, (150, 150, 150), self.small)
        pulse = 150 + int(80 * (math.sin(pygame.time.get_ticks() / 350) + 1) / 2)
        pygame.draw.circle(self.canvas, (70, pulse, 100) if self.audio_ok else (190,70,60), (18, HEIGHT-25), 5)
        audio = "Audio ON" if self.audio_ok and not self.audio_muted else ("Audio muted" if self.audio_ok else "Audio unavailable")
        self.text(f"F11 Fullscreen   M {audio}   Mouse enabled", 32, HEIGHT - 34, (185, 185, 180), self.small)

    def draw_create(self):
        self.canvas.fill((7, 10, 12)); self.text("CREATE AN ADVENTURER", WIDTH//2, 38, (250,205,91), self.mono_large, True)
        self.text("Choose a race, a calling, and one of the three descents.", WIDTH//2, 76, (180,195,190), self.mono_small, True)
        self.panel(pygame.Rect(120, 95, 720, 505))
        labels = [
            ("NAME", self.name_text), ("RACE", self.create_values[0]),
            ("CLASS", self.create_values[1]), ("DUNGEON", self.create_values[2]),
            ("FATE", self.create_values[3]), ("BEGIN", "Enter the Lamplight Guild"),
        ]
        for i, (label, value) in enumerate(labels):
            y = 127 + i * 76; active = i == self.create_row
            color = (255, 207, 87) if active else (225, 225, 214)
            self.text((">" if active else " ") + label, 155, y, color, self.mono)
            self.text(value + ("_" if active and i == 0 else ""), 365, y, color, self.mono)
        race, klass = self.create_values[:2]
        portrait = self.assets["portraits"][(race, klass, "large")]
        self.canvas.blit(portrait, (975, 105))
        temp = default_player(self.name_text, race, klass, self.create_values[3] == "Classic", self.create_values[2])
        self.panel(pygame.Rect(875, 275, 350, 325))
        self.text(f"{race.upper()} {klass.upper()}", 905, 300, (255,207,87), self.mono)
        for i, key in enumerate(("str","int","wis","con","dex","cha")):
            self.text(f"{key.upper():3} {temp['stats'][key]:2}", 905 + (i%2)*145, 345 + (i//2)*34, (210,220,215), self.mono_small)
        self.text(f"HIT POINTS {temp['max_hp']:2}", 905, 458, (150,225,165), self.mono_small)
        self.text(f"SPIRIT     {temp['max_sp']:2}", 905, 487, (140,195,240), self.mono_small)
        for i, line in enumerate(self.wrap(DUNGEONS[self.create_values[2]]["description"], 29)):
            self.text(line, 905, 530 + i*21, (190,190,180), self.mono_small)
        mode_text = "CLASSIC: death erases the save." if self.create_values[3] == "Classic" else "ADVENTURE: defeat returns you to town."
        self.text(mode_text, WIDTH//2, 636, (205,180,125), self.mono_small, True)
        self.text("Arrows choose · Enter begins · Esc returns", WIDTH//2, 676, (155,165,162), self.mono_small, True)

    def draw_town(self):
        self.canvas.fill((15, 20, 22)); self.text("THE LAMPLIGHT GUILD", WIDTH//2, 50, (250,205,91), self.large, True)
        self.panel(pygame.Rect(90, 105, 1100, 500))
        p = self.player; portrait = self.assets["portraits"][(p["race"], p["class"], "large")]
        self.canvas.blit(portrait, (145, 155))
        self.text(f"{p['name']}, {p['race']} {p['class']}", 330, 150, (240,240,225), self.large)
        deepest = p.get("deepest_floor", p["floor"])
        self.text(f"{p.get('dungeon', 'Moonroot Warrens')} · Level {p['level']} · Deepest {deepest} ({deepest*50} feet)", 333, 205)
        self.text(f"Banked gold: {p['bank']}    Potions: {p['potions']}    Torches: {p['torches']}", 333, 250, (190,220,190))
        self.text("1  Enter the dungeon", 340, 330, (255,207,87), self.large)
        self.text("2  Buy healing potion — 35 gold", 340, 395)
        self.text("3  Buy torch — 10 gold", 340, 440)
        self.text("Q  Save and return to title", 340, 505)
        self.text("Treasure is banked only when you return alive.", 330, 560, (205,170,120), self.small)
        self.draw_messages(625)

    def draw_dungeon(self):
        self.canvas.fill((4, 7, 9)); p = self.player
        dungeon = p.get("dungeon", "Moonroot Warrens")
        self.text(f"{dungeon.upper()}  ·  LEVEL {p['floor']}  ·  {p['floor']*50} FEET", MAP_X, 22, (250,205,91), self.mono)
        pygame.draw.rect(self.canvas, (25, 29, 30), (MAP_X-3, MAP_Y-3, MAP_W*TILE+6, MAP_H*TILE+6), 2)
        for y in range(MAP_H):
            for x in range(MAP_W):
                if (x, y) not in self.seen: continue
                tile = self.grid[y][x]
                image = self.assets["env"][ENV_TILES.get(tile, 0)]
                if not self.visible(x, y):
                    image = image.copy(); image.fill((65,65,68), special_flags=pygame.BLEND_MULT)
                self.canvas.blit(image, (MAP_X+x*TILE, MAP_Y+y*TILE))
                if tile == "#" and self.wall_has_sconce(x, y):
                    self.draw_sconce(MAP_X+x*TILE, MAP_Y+y*TILE, self.visible(x, y))
        for enemy in self.enemies:
            if self.visible(enemy["x"], enemy["y"]):
                self.canvas.blit(self.assets["env"][enemy["tile"]], (MAP_X+enemy["x"]*TILE, MAP_Y+enemy["y"]*TILE))
        self.canvas.blit(self.assets["portraits"][(p["race"], p["class"], "tile")], (MAP_X+self.px*TILE, MAP_Y+self.py*TILE))
        self.draw_hud()
        self.panel(pygame.Rect(MAP_X, 570, 860, 126), 218, (66, 78, 75))
        self.text("EXPEDITION LOG", MAP_X+16, 582, (166,180,175), self.mono_small)
        y = 607
        for message in self.messages[-3:]:
            self.text(message, MAP_X+18, y, (225,225,212), self.mono_small)
            y += 23
        self.text("MOVE: WASD/ARROWS (X=SOUTH)   E USE   T TORCH   . WAIT   F5 SAVE   ESC MENU", MAP_X+12, 675, (250,205,91), self.mono_small)

    def wall_has_sconce(self, x, y):
        if not any(
            0 <= x + dx < MAP_W and 0 <= y + dy < MAP_H
            and self.grid[y + dy][x + dx] != "#"
            for dx, dy in ((0, 1), (1, 0), (0, -1), (-1, 0))
        ):
            return False
        floor = self.player["floor"] if self.player else 0
        return ((x * 73856093) ^ (y * 19349663) ^ (floor * 83492791)) % 71 == 0

    def draw_sconce(self, x, y, bright):
        metal = (116, 91, 49) if bright else (61, 58, 52)
        flame = (255, 181, 55) if bright else (105, 87, 52)
        pygame.draw.line(self.canvas, metal, (x + TILE // 2, y + 9),
                         (x + TILE // 2, y + 16), 2)
        pygame.draw.circle(self.canvas, flame, (x + TILE // 2, y + 7), 3)

    def draw_hud(self):
        p = self.player
        self.panel(pygame.Rect(PANEL_X, MAP_Y, 330, 624), 225, (66, 78, 75))
        name = p["name"].upper()
        name_font = self.mono_large if self.mono_large.size(name)[0] <= 294 else self.mono
        self.text(name, PANEL_X+18, MAP_Y+16, (245,245,228), name_font)
        self.text(f"{p['race'].upper()}  {p['class'].upper()}", PANEL_X+20, MAP_Y+55, (105,225,220), self.mono)
        portrait = pygame.transform.scale(self.assets["portraits"][(p["race"], p["class"], "large")], (96,96))
        self.canvas.blit(portrait, (PANEL_X+20, MAP_Y+94))
        self.text(f"LEVEL {p['level']:>4}", PANEL_X+135, MAP_Y+96, (255,207,87), self.mono)
        self.text(f"HP {p['hp']:>3}/{p['max_hp']:<3}", PANEL_X+135, MAP_Y+128, (140,235,155), self.mono_small)
        self.bar(PANEL_X+135, MAP_Y+151, 165, p["hp"]/p["max_hp"], (55,175,78))
        self.text(f"SP {p['sp']:>3}/{p['max_sp']:<3}", PANEL_X+135, MAP_Y+168, (130,190,245), self.mono_small)
        self.bar(PANEL_X+135, MAP_Y+191, 165, p["sp"]/max(1,p["max_sp"]), (48,125,205))
        self.text("ATTRIBUTES", PANEL_X+20, MAP_Y+218, (166,180,175), self.mono_small)
        for i, key in enumerate(("str","int","wis","dex","con","cha")):
            self.text(f"{key.upper():3} {p['stats'][key]:>2}", PANEL_X+20+(i%2)*145, MAP_Y+245+(i//2)*28, (225,225,212), self.mono_small)
        self.text(f"EXPERIENCE  {p['xp']:>5}/{p['next_xp']:<5}", PANEL_X+20, MAP_Y+340, (225,225,212), self.mono_small)
        self.text(f"GOLD BANKED {p['bank']:>7}", PANEL_X+20, MAP_Y+372, (190,220,190), self.mono_small)
        self.text(f"GOLD CARRIED{p['carried']:>7}", PANEL_X+20, MAP_Y+400, (255,195,90), self.mono_small)
        self.text(f"POTIONS     {p['potions']:>7}", PANEL_X+20, MAP_Y+438, (225,225,212), self.mono_small)
        self.text(f"TORCHES     {p['torches']:>7}", PANEL_X+20, MAP_Y+466, (225,225,212), self.mono_small)
        self.text(f"LIGHT       {p.get('light_turns',0):>7}", PANEL_X+20, MAP_Y+494, (235,205,120), self.mono_small)
        self.text(f"DEPTH       {p['floor']*50:>5} FT", PANEL_X+20, MAP_Y+532, (180,195,190), self.mono_small)
        mode = "CLASSIC / PERMADEATH" if p.get("classic") else "ADVENTURE / RECOVERY"
        self.text(mode, PANEL_X+20, MAP_Y+574, (205,170,120), self.mono_small)

    def bar(self, x, y, w, ratio, color):
        pygame.draw.rect(self.canvas, (45,45,45), (x,y,w,12), border_radius=4)
        pygame.draw.rect(self.canvas, color, (x,y,int(w*clamp(ratio,0,1)),12), border_radius=4)

    @staticmethod
    def wrap(text, width):
        words, lines, line = text.split(), [], []
        for word in words:
            if len(" ".join(line+[word])) > width and line:
                lines.append(" ".join(line)); line=[]
            line.append(word)
        if line: lines.append(" ".join(line))
        return lines

    def draw_combat(self):
        self.canvas.fill((5, 7, 9)); p, e = self.player, self.combat_enemy
        self.draw_hud()
        glow = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        pygame.draw.circle(glow, (110,62,20,90), (800,225), 240); self.canvas.blit(glow,(0,0))
        self.text(f"YOU HAVE ENCOUNTERED A {e['name'].upper()}", 800, 34, (250,205,91), self.mono_large, True)
        monster = self.assets["env_large"][e["tile"]]
        self.canvas.blit(monster, monster.get_rect(center=(800,220)))
        self.bar(650, 365, 300, e["hp"]/e["max_hp"], (177,55,48))
        self.text(f"{e['hp']} / {e['max_hp']} HIT POINTS", 800, 392, (230,220,210), self.mono_small, True)
        self.panel(pygame.Rect(340, 435, 900, 220), 225, (66,78,75))
        skill = {"Knight":"Guard", "Archer":"Aimed shot (2 SP)", "Priest":"Healing prayer (3 SP)", "Mage":"Magic Missile (3 SP)"}[p["class"]]
        options = ["[F] Fight", f"[C] {skill}", f"[H] Healing potion ({p['potions']})", "[E] Evade", "[S] Stay and watch"]
        for i, option in enumerate(options):
            color = (255,207,87) if i == self.combat_choice else (228,228,215)
            prefix = ">" if i == self.combat_choice else " "
            col, row = i%2, i//2
            self.text(f"{i+1}. {prefix} {option}", 365+col*430, 475+row*55, color, self.mono_small)
        self.text(self.messages[-1], 790, 671, (190,215,195), self.mono_small, True)

    def draw_pause(self):
        self.draw_dungeon(); shade=pygame.Surface((WIDTH,HEIGHT),pygame.SRCALPHA); shade.fill((0,0,0,155)); self.canvas.blit(shade,(0,0))
        self.panel(pygame.Rect(430,210,420,270)); self.text("PAUSED", WIDTH//2, 250, (250,205,91), self.large, True)
        for i, label in enumerate(("Continue", "Save and return to title")):
            color=(255,207,87) if i==self.pause_choice else (230,230,220)
            self.text(("> " if i==self.pause_choice else "  ")+label, 485, 325+i*65, color)

    def draw_help(self):
        self.canvas.fill((10,14,18)); self.text("CONTROLS & RULES", WIDTH//2, 50, (250,205,91), self.large, True)
        self.panel(pygame.Rect(150,100,980,520))
        lines = [
            "WASD / Arrow keys    Move one dungeon turn (X also moves south)", "E / Enter             Use stairs or interact",
            "T                     Light a torch", "Space / .             Wait one turn", "F5                    Save", "Esc / Q                Pause and save/quit",
            "F11                   Toggle fullscreen", "M                     Mute/unmute audio", "Mouse                 Menus and combat choices are clickable", "", "Combat: F fight, C class skill, H heal, E evade, S wait.",
            "Arrows/Enter and number keys 1–5 also operate the encounter menu.",
            "Gold carried inside the dungeon is not safe until you return to town.",
            "Adventure mode rescues a defeated hero. Classic mode permanently deletes the save.",
            "Moonroot is fair; Emberdeep is dangerous; Glass Catacomb is severe.",
            "Reach level 20, claim the Orb, and return immortal.", "Press Enter or Esc to return."
        ]
        for i, line in enumerate(lines):
            color = (230, 230, 218) if i < 10 else (195, 205, 198)
            self.text(line, 205, 126 + i * 29, color, self.small)

    def draw_dead(self):
        self.canvas.fill((17,7,8)); self.text("THE DUNGEON CLAIMS ANOTHER", WIDTH//2, 150, (220,80,65), self.large, True)
        classic = self.player and self.player.get("classic")
        msg = "Your character and save are gone." if classic else "The guild retrieves you, but your carried treasure is gone."
        self.text(msg, WIDTH//2, 250, (235,225,215), self.font, True)
        self.text("Press Enter", WIDTH//2, 350, (250,205,91), self.font, True)

    def draw_victory(self):
        self.canvas.fill((10,16,20)); self.text("THE ORB OF LAMPLIGHT", WIDTH//2, 135, (250,205,91), self.title_font, True)
        self.text("You have crossed twenty levels and earned immortality.", WIDTH//2, 260, (235,235,220), self.font, True)
        self.text(f"{self.player['name']} returns with {self.player['kills']} victories and {self.player['bank'] + self.player['carried']} gold.", WIDTH//2, 315, (180,220,190), self.font, True)
        self.text("Press Enter", WIDTH//2, 430, (250,205,91), self.font, True)

    def draw_messages(self, y):
        if self.messages: self.text(self.messages[-1], WIDTH//2, y, (205,205,195), self.small, True)

    def draw(self):
        if self.state == "title": self.draw_title()
        elif self.state == "create": self.draw_create()
        elif self.state == "town": self.draw_town()
        elif self.state == "dungeon": self.draw_dungeon()
        elif self.state == "combat": self.draw_combat()
        elif self.state == "pause": self.draw_pause()
        elif self.state == "help": self.draw_help()
        elif self.state == "dead": self.draw_dead()
        elif self.state == "victory": self.draw_victory()
        ww, wh = self.window.get_size()
        scale = min(ww / WIDTH, wh / HEIGHT)
        target_size = (max(1, round(WIDTH * scale)), max(1, round(HEIGHT * scale)))
        target = pygame.transform.smoothscale(self.canvas, target_size)
        self.window.fill((0, 0, 0))
        self.window.blit(target, ((ww - target_size[0]) // 2, (wh - target_size[1]) // 2))
        pygame.display.flip()

    def run(self):
        while self.running:
            for event in pygame.event.get(): self.handle_event(event)
            self.draw(); self.clock.tick(60)
        pygame.quit()


if __name__ == "__main__":
    Game().run()
