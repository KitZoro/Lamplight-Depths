# Changelog

## 0.2.2

- Preserved every visited dungeon level so climbing back restores the same map, monsters, treasure, and exploration.
- Spawned arrivals beside staircases instead of directly on an exit.
- Required the interaction key to be released before another staircase can activate, preventing held-key level skipping.
- Replaced the wall tile's repeated baked-in torch with consistent stonework and sparse deterministic sconces.
- Added save-format version 4 with validation and automatic migration of older saves.

## 0.2.1

- Fixed damaged saves with an invalid player record crashing instead of returning safely to the title screen.
- Made every allowed adventurer name fit inside the dungeon and combat status panel.
- Cleared stale floor and encounter data when returning to town, reducing save size and preventing old expedition state from lingering.

## 0.2.0

- Rebuilt exploration around a readable DEC DND-style split screen: character record on the left, dungeon map on the right, and commands and expedition messages below.
- Reworked encounters into a mainframe-inspired command screen while retaining graphical furry portraits, monster art, mouse control, health bars, music and sound.
- Added direct encounter commands: **F** fight, **C** class skill, **H** heal, **E** evade and **S** stay.
- Added three original selectable campaigns: Moonroot Warrens, Emberdeep Vault and Glass Catacomb.
- Gave the harder campaigns stronger populations and proportionally richer treasure.
- Added **X** as a second south key in homage to the original DEC control arrangement while retaining WASD and arrow movement.
- Added save-format version 3 and automatic migration of older Lamplight saves to Moonroot Warrens.

## 0.1.5

- Fixed fresh torches sometimes adding only a single turn of light; each torch now adds 120 turns.
- Made successful altar offerings consume a dungeon turn so nearby enemies cannot be frozen.
- Made the launcher detect and repair environments where Python exists but Pygame is missing.
- Made the installer repair missing package support inside an existing environment.
- Rejected unsupported or internally inconsistent save formats before they can be rewritten.
- Cleared stale encounter state whenever a floor or save is replaced.

## 0.1.4

- Fixed combat saves loading outside the active encounter.
- Fixed altars taking gold simply when the player stepped onto them; offerings now require **E**.
- Fixed deepest-level progress being lost after climbing back to town.
- Made victories persistent and safely banked carried treasure when the Orb is claimed.
- Prevented healing prayers, potions and full-spirit offerings from wasting resources.
- Added save-format version 2 while retaining compatibility with earlier saves.

## 0.1.3

- Fixed Classic-mode permadeath saves being recreated after fatal combat or quitting.
- Fixed the global mute shortcut preventing **M** and **m** in adventurer names.
- Added strict save validation so damaged data is rejected instead of crashing the game.
- Preserved compatibility with saves from versions 0.1.1 and 0.1.2.
- Made the installer repair incomplete virtual environments and removed an unnecessary pip upgrade.

## 0.1.2

- Fixed Adventure-mode rescue saves incorrectly reopening inside the dungeon.
- Fixed poisoned fountains allowing the player to remain alive at zero HP.
- Made torches functional: **T** lights one for 120 turns; darkness reduces sight range.
- Added a guaranteed Orb guardian to dungeon level 20.
- Made save writes atomic to reduce the risk of a damaged save after interruption.
- Preserved the game's aspect ratio in resized and fullscreen windows and corrected mouse mapping.

## 0.1.1

- Added an original two-minute looping dungeon soundtrack.
- Added distinct menu, movement, combat, treasure, healing, danger and stair sounds.
- Added mouse interaction to the title, creation, town, combat and pause screens.
- Added an animated status indicator so an idle menu visibly remains responsive.
- Added **M** to mute and unmute audio.
- Preserved keyboard-only operation and safe fallback when Linux audio initialization fails.

## 0.1.0

- Initial playable Linux release.
